<?php

require __DIR__ . "/hacienda/firmador.php";

use Hacienda\Firmador;

if ($argc < 5) {
    fwrite(
        STDERR,
        "Uso: php wrapper.php certificado.p12 pin input.xml output.xml\n",
    );
    exit(1);
}

$p12 = $argv[1];
$pin = $argv[2];
$inputXmlPath = $argv[3];
$outputXml = $argv[4];

try {
    if (!file_exists($inputXmlPath)) {
        throw new Exception("XML no existe: " . $inputXmlPath);
    }

    $xmlContent = file_get_contents($inputXmlPath);

    if (!$xmlContent) {
        throw new Exception("No se pudo leer XML");
    }

    $firmador = new Firmador();

    $xmlFirmado = $firmador->firmarXml(
        $p12,
        $pin,
        $xmlContent,
        $firmador::TO_XML_STRING,
    );

    if (!$xmlFirmado) {
        throw new Exception("No se pudo firmar XML");
    }

    file_put_contents($outputXml, $xmlFirmado);

    echo "OK\n";
} catch (Exception $e) {
    fwrite(STDERR, $e->getMessage() . PHP_EOL);

    exit(1);
}
